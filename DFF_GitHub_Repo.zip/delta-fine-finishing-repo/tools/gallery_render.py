"""Gallery HTML for deltafinefinishing.com.

Used in two places so the page is always built the same way:
  * build_site.py   -> the page that ships in the ZIP (and the preview)
  * tools/sync_instagram.py -> the GitHub Action that re-renders gallery.html and sitemap.xml after new Instagram posts

Only the standard library is used. Everything that comes from Instagram (captions, links) is escaped here.
"""
import datetime
import hashlib
import html
import json
import os
import re
import unicodedata

SITE = "https://www.deltafinefinishing.com/"
IG_PROFILE = "https://www.instagram.com/dfinefinishing/"
IG_HANDLE = "@dfinefinishing"
BIZ = "Delta Fine Finishing"
WIDTHS = (480, 960, 1600)          # WebP sizes made for every photo
SIZES_ATTR = "(min-width:1500px) 25vw,(min-width:1000px) 33vw,(min-width:600px) 50vw,100vw"

TITLE = "Custom Cabinetry Project Gallery | Brookfield, CT"
DESC_FULL = "Photos of our custom cabinetry, kitchens and MDF cabinet doors from Brookfield, CT. New projects are added straight from our Instagram."
DESC_SOON = "The Delta Fine Finishing project gallery is coming soon. Follow our latest kitchens and custom cabinetry on Instagram and Facebook."

DEFAULT_CFG = {
    "max_on_page": 120,
    "max_stored_posts": 400,
    "default_category": "Projects",
    "alt_fallback": "Custom cabinetry project by Delta Fine Finishing in Brookfield, CT",
    "alt_fallbacks": {
        "Kitchens": "Custom kitchen cabinetry by Delta Fine Finishing in Brookfield, CT",
        "Bathrooms": "Custom bathroom vanity cabinetry by Delta Fine Finishing in Brookfield, CT",
        "Closets & built-ins": "Custom built-in cabinetry by Delta Fine Finishing in Brookfield, CT",
        "Cabinet doors": "MDF cabinet doors made by Delta Fine Finishing in Brookfield, CT",
        "Shop & process": "Inside the Delta Fine Finishing cabinet shop in Brookfield, CT",
    },
    # the first group whose word matches the caption or hashtags wins; edit data/config.json to change
    "categories": [
        ["Kitchens", ["kitchen", "cozinha", "island", "pantry", "backsplash"]],
        ["Bathrooms", ["bath", "vanity", "banheiro", "powder room"]],
        ["Closets & built-ins", ["closet", "built-in", "builtin", "bookcase", "shelving", "wardrobe", "armario", "armário", "mudroom", "entertainment"]],
        ["Cabinet doors", ["door", "porta", "shaker", "fluted", "slab", "drawer front", "mdf"]],
        ["Shop & process", ["shop", "cnc", "spray", "primer", "finishing", "oficina", "pintura", "process"]],
    ],
}

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
MONTHS_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
_PERMALINK = re.compile(r"^https://www\.instagram\.com/(?:p|reel|reels|tv)/[A-Za-z0-9_-]+/?$")


# ------------------------------------------------------------------ data files
def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def load_config(data_dir):
    cfg = json.loads(json.dumps(DEFAULT_CFG))
    user = load_json(os.path.join(data_dir, "config.json"), {})
    if isinstance(user, dict):
        for k, v in user.items():
            if k in cfg and not str(k).startswith("_"):
                cfg[k] = v
    return cfg


def load_overrides(data_dir):
    ov = load_json(os.path.join(data_dir, "overrides.json"), {})
    return ov if isinstance(ov, dict) else {}


def load_archive(data_dir):
    a = load_json(os.path.join(data_dir, "gallery.json"), {})
    if not isinstance(a, dict) or not isinstance(a.get("posts"), list):
        a = {"version": 1, "posts": []}
    return a


# ------------------------------------------------------------------ text helpers
esc = lambda s: html.escape("" if s is None else str(s), quote=True)
_URL = re.compile(r"https?://\S+|www\.\S+", re.I)
_TAG = re.compile(r"(?<![\w])#\w+", re.U)
_MENTION = re.compile(r"(?<![\w])@[\w.]+", re.U)


def _strip_symbols(s):
    out = []
    for c in s:
        cat = unicodedata.category(c)
        if cat in ("Cs", "Cn", "Co", "Cf") or (cat in ("So", "Sk") and ord(c) > 0x2000) or c in "\ufe0f\u200d":
            continue
        out.append(c)
    return "".join(out)


def clean_lines(raw):
    """Caption as plain readable lines: no links, #hashtags, @mentions or emoji."""
    s = _strip_symbols(_MENTION.sub(" ", _TAG.sub(" ", _URL.sub(" ", raw or ""))))
    lines = []
    for ln in s.replace("\r", "").split("\n"):
        ln = re.sub(r"\s+", " ", ln).strip(" \t-–—•·|:*_~.,;")
        if re.search(r"[A-Za-z0-9\u00c0-\u024f]{2}", ln):
            lines.append(ln)
    return lines


def shorten(s, n):
    s = (s or "").strip()
    if len(s) <= n:
        return s
    cut = s[:n]
    m = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
    if m >= int(n * 0.45):
        return cut[:m + 1].strip()
    sp = cut.rfind(" ")
    cut = cut[:sp] if sp >= int(n * 0.45) else cut
    return cut.rstrip(" ,;:-–—") + "\u2026"


def _sentences(lines):
    out = []
    for ln in lines:
        out.append(ln if re.search(r"[.!?]$", ln) else ln + ".")
    return " ".join(out)


def parse_ts(ts):
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)", ts or "")
    if not m:
        return None
    try:
        return datetime.datetime(*[int(x) for x in m.groups()])
    except ValueError:
        return None


def iso(ts):
    d = parse_ts(ts)
    return d.strftime("%Y-%m-%dT%H:%M:%SZ") if d else None


def date_label(ts):
    d = parse_ts(ts)
    return f"{MONTHS[d.month - 1]} {d.day}, {d.year}" if d else ""


def month_label(ts):
    d = parse_ts(ts)
    return f"{MONTHS_LONG[d.month - 1]} {d.year}" if d else ""


def slugify(s, maxlen=44):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    words = [w for w in re.split(r"[^a-z0-9]+", s) if w]
    out = ""
    for w in words[:7]:
        if len(out) + len(w) + 1 > maxlen:
            break
        out += ("-" if out else "") + w
    return out


def short_id(post_id):
    return hashlib.sha1(str(post_id).encode()).hexdigest()[:6]


def category_of(raw, cfg):
    text = (raw or "").lower()
    for name, words in cfg["categories"]:
        for w in words:
            if re.search(r"(?<![a-z0-9\u00e0-\u00ff])" + re.escape(w.lower()), text):
                return name
    return cfg["default_category"]


def safe_permalink(p):
    return p if isinstance(p, str) and _PERMALINK.match(p) else None


# ------------------------------------------------------------------ posts -> flat list of gallery items
def _hex(c):
    return c if isinstance(c, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", c) else "#e8edf3"


def is_hidden(p, overrides):
    """True when the owner listed this post (id, short code from the Instagram link, or the link itself) under "hide" in data/overrides.json."""
    hide = {str(x).strip() for x in overrides.get("hide", []) if str(x).strip()}
    if {str(p.get("id")), str(p.get("shortcode"))} & hide:
        return True
    return any(len(h) > 5 and h.rstrip("/") in (p.get("permalink") or "") for h in hide)


def derive_items(posts, cfg, overrides):
    pov = overrides.get("posts", {}) if isinstance(overrides.get("posts"), dict) else {}
    items = []
    for p in sorted(posts, key=lambda q: q.get("ts", ""), reverse=True):
        if is_hidden(p, overrides):
            continue
        ov = pov.get(str(p.get("shortcode"))) or pov.get(str(p.get("id"))) or {}
        lines = clean_lines(p.get("caption", ""))
        cat = ov.get("category") or category_of(p.get("caption", ""), cfg)
        title = ov.get("title") or shorten(lines[0], 70) if lines else (ov.get("title") or "")
        base_alt = ov.get("alt") or (shorten(_sentences(lines), 125) if lines else "")
        fallback = cfg["alt_fallbacks"].get(cat, cfg["alt_fallback"])
        when = month_label(p.get("ts"))
        cap = ov.get("caption") if "caption" in ov else shorten(_sentences(lines), 240)
        files = p.get("files", [])
        for i, f in enumerate(files):
            alt = ov.get("alt") or f.get("alt") or base_alt or (f"{fallback} ({when})" if when else fallback)
            alt = shorten(alt, 160)
            if len(files) > 1:
                alt = f"{alt} (photo {i + 1} of {len(files)})"
            items.append(dict(
                id=f"{p['id']}-{i}", post=str(p["id"]), shortcode=p.get("shortcode"), permalink=safe_permalink(p.get("permalink")),
                video=bool(p.get("video")), title=title, alt=alt, caption=cap, category=cat, ts=iso(p.get("ts")), date=date_label(p.get("ts")),
                base=f["base"], sizes=list(f["sizes"]), w=int(f["w"]), h=int(f["h"]), bg=_hex(f.get("bg")),
            ))
    return items[:int(cfg.get("max_on_page", 120))]


def _src_width(it):
    ok = [w for w in it["sizes"] if w <= 960]
    return max(ok) if ok else min(it["sizes"])


def img_urls(it, prefix="gallery/"):
    f = lambda w: f"{prefix}{it['base']}-{w}.webp"
    return f(_src_width(it)), f(max(it["sizes"])), f(min(it["sizes"]))


# ------------------------------------------------------------------ HTML
PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>'


def _tile(it, i, prefix):
    src, full, _small = img_urls(it, prefix)
    sw = _src_width(it)
    sh = max(1, round(sw * it["h"] / it["w"]))
    ss = ", ".join(f"{prefix}{it['base']}-{w}.webp {w}w" for w in sorted(it["sizes"]) if w <= 960) if len(it["sizes"]) > 1 else ""
    first = i == 0
    img = (f'<img src="{esc(src)}"' + (f' srcset="{esc(ss)}" sizes="{SIZES_ATTR}"' if ss and len(ss.split(",")) > 1 else "")
           + f' width="{sw}" height="{sh}" alt="{esc(it["alt"])}"' + (' fetchpriority="high"' if first else ' loading="lazy"') + ' decoding="async">')
    cap = f'<span class="gcap">{esc(it["title"])}</span>' if it["title"] else ""
    style = f' style="background:{it["bg"]}"'
    if it["video"] and it["permalink"]:
        lab = f'Watch on Instagram: {it["title"]}' if it["title"] else "Watch this video on Instagram"
        return (f'<li class="gvid" data-cat="{esc(it["category"])}"><a class="gitem" href="{esc(it["permalink"])}" target="_blank" rel="noopener"{style} '
                f'aria-label="{esc(lab)} (opens in a new tab)">{img}<span class="gplay" aria-hidden="true">{PLAY}</span>{cap}</a></li>')
    lab = f'View larger: {it["title"]}' if it["title"] else "View larger photo"
    data = (f'data-full="{esc(full)}" data-alt="{esc(it["alt"])}" data-cap="{esc(it["caption"] or it["date"])}"'
            + (f' data-ig="{esc(it["permalink"])}"' if it["permalink"] else ""))
    return f'<li data-cat="{esc(it["category"])}"><button type="button" class="gitem"{style} {data} aria-label="{esc(lab)}">{img}{cap}</button></li>'


def render_filters(items):
    order = [c for c, _w in DEFAULT_CFG["categories"]]
    used = []
    for it in items:
        if it["category"] not in used:
            used.append(it["category"])
    used.sort(key=lambda c: (order.index(c) if c in order else 99, c))
    if len(used) < 2:
        return ""
    btn = lambda c: f'<button type="button" data-cat="{esc(c)}" aria-pressed="false">{esc(c)}</button>'
    return '<div class="gfilters" role="group" aria-label="Filter photos by type">' + btn("All") + "".join(btn(c) for c in used) + "</div>"


LIGHTBOX = (
    '<div class="lb" id="lb" role="dialog" aria-modal="true" aria-label="Photo viewer" hidden>'
    '<button type="button" class="lb-x" aria-label="Close photo viewer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    '<button type="button" class="lb-p" aria-label="Previous photo"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg></button>'
    '<figure><img alt="" id="lb-img"><figcaption><span id="lb-cap"></span> <a id="lb-ig" href="#" target="_blank" rel="noopener">View on Instagram</a></figcaption></figure>'
    '<button type="button" class="lb-n" aria-label="Next photo"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg></button></div>'
)

SOON = f'''<main>
  <section class="soon" aria-labelledby="h1">
    <div class="wrap">
      <div class="soon-card">
        <img class="soon-logo" src="__LOGO_LG__" width="__LOGO_LG_W__" height="400" alt="Delta Fine Finishing logo: a navy and red oval badge showing a paint spray gun inside a golden sunburst">
        <span class="badge">Photos coming soon</span>
        <h1 id="h1">Gallery</h1>
        <p class="lead">We are putting together photos of our kitchens and custom cabinetry. The gallery fills up automatically from our Instagram.</p>
        <p class="sub">In the meantime, follow our latest projects on social media or ask us about your own.</p>
        <div class="btns">
          <a class="btn" href="{IG_PROFILE}" target="_blank" rel="noopener">Follow us on Instagram</a>
          <a class="btn ghost" href="https://www.facebook.com/profile.php?id=61566378143354" target="_blank" rel="noopener">Facebook</a>
          <a class="btn ghost" href="door-order.html">Place a door order</a>
        </div>
      </div>
    </div>
  </section>
</main>'''


def render_main(items, prefix="gallery/"):
    if not items:
        return SOON
    tiles = "".join(_tile(it, i, prefix) for i, it in enumerate(items))
    return f'''<main>
  <section class="ghead" aria-labelledby="h1">
    <div class="wrap">
      <h1 id="h1">Project gallery</h1>
      <p>Custom cabinetry, kitchens and MDF cabinet doors from our shop in Brookfield, Connecticut. New photos are added automatically from our Instagram.</p>
      <p><a class="btn ghost igl" href="{IG_PROFILE}" target="_blank" rel="noopener">Follow {IG_HANDLE} on Instagram</a></p>
    </div>
  </section>
  <section class="gal">
    <div class="wrap">
      {render_filters(items)}
      <ul class="ggrid" id="ggrid">{tiles}</ul>
      <p class="gnote">Want to see more? Every project we post is on <a href="{IG_PROFILE}" target="_blank" rel="noopener">Instagram</a>.</p>
      <div class="gcta">
        <div><strong>Have a project in mind?</strong><span>Tell us about it and we will get back to you.</span></div>
        <div class="btns"><a class="btn" href="__HOME__#contact">Contact us</a><a class="btn ghost" href="door-order.html">Door Order</a></div>
      </div>
    </div>
  </section>
</main>
{LIGHTBOX}'''


def _ld_json(obj):
    s = json.dumps(obj, ensure_ascii=False, indent=1)
    return s.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def render_head(items):
    """robots + JSON-LD for the head. Empty gallery stays out of Google until the first photo arrives."""
    if not items:
        return '<meta name="robots" content="noindex">\n'
    org = {"@type": "Organization", "name": BIZ, "url": SITE}
    imgs = []
    for it in items[:24]:
        src, full, _s = img_urls(it, SITE + "gallery/")
        sw = _src_width(it)
        o = {"@type": "ImageObject", "contentUrl": full, "thumbnailUrl": src, "name": it["title"] or it["alt"], "caption": it["alt"],
             "width": max(it["sizes"]), "height": max(1, round(max(it["sizes"]) * it["h"] / it["w"])), "creator": org, "copyrightHolder": org, "creditText": BIZ}
        if it["caption"] and it["caption"] != it["alt"]:
            o["description"] = it["caption"]
        if it["ts"]:
            o["uploadDate"] = it["ts"]
        imgs.append(o)
    latest = next((it["ts"] for it in items if it["ts"]), None)
    graph = [
        {"@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Home", "item": SITE},
            {"@type": "ListItem", "position": 2, "name": "Gallery", "item": SITE + "gallery.html"}]},
        {"@type": "ImageGallery", "@id": SITE + "gallery.html#gallery", "url": SITE + "gallery.html", "name": "Delta Fine Finishing project gallery",
         "description": DESC_FULL, "inLanguage": "en-US", "about": {"@type": "Thing", "name": "Custom cabinetry and kitchen renovation in Brookfield, Connecticut"},
         "publisher": org, **({"dateModified": latest} if latest else {}), "image": imgs},
    ]
    return '<script type="application/ld+json">\n' + _ld_json({"@context": "https://schema.org", "@graph": graph}) + "\n</script>\n"


def sitemap_entry(items):
    if not items:
        return ""
    lastmod = next((it["ts"][:10] for it in items if it["ts"]), datetime.date.today().isoformat())
    seen, imgs = set(), ""
    for it in items:
        u = SITE + f"gallery/{it['base']}-{max(it['sizes'])}.webp"
        if u not in seen:
            seen.add(u)
            imgs += f"<image:image><image:loc>{esc(u)}</image:loc></image:image>"
    return f"  <url><loc>{SITE}gallery.html</loc><lastmod>{lastmod}</lastmod>{imgs}</url>\n"


# ------------------------------------------------------------------ markers in the shipped files
MAIN_A, MAIN_B = "<!--gal:main-->", "<!--/gal:main-->"
HEAD_A, HEAD_B = "<!--gal:head-->", "<!--/gal:head-->"
SM_A, SM_B = "<!--gal:sitemap-->", "<!--/gal:sitemap-->"
DEFAULT_SUBS = {"__LOGO_LG__": "logo-large.webp", "__LOGO_LG_W__": "283", "__HOME__": "/"}


def _swap(text, a, b, new):
    i, j = text.index(a) + len(a), text.index(b)
    return text[:i] + new + text[j:]


def apply_gallery(page_html, items, subs=None, prefix="gallery/"):
    """Fill the three marked regions of gallery.html (title/description follow the state too)."""
    subs = DEFAULT_SUBS if subs is None else subs
    main = render_main(items, prefix)
    for k, v in subs.items():
        main = main.replace(k, v)
    out = _swap(page_html, MAIN_A, MAIN_B, "\n" + main + "\n")
    out = _swap(out, HEAD_A, HEAD_B, "\n" + render_head(items))
    a, b = (esc(DESC_SOON), esc(DESC_FULL)) if items else (esc(DESC_FULL), esc(DESC_SOON))
    return out.replace(f'content="{a}"', f'content="{b}"')


def apply_sitemap(xml, items):
    return _swap(xml, SM_A, SM_B, "\n" + sitemap_entry(items))


def sample_items():
    """Every markup variant, only used so the build keeps the CSS that the live gallery needs."""
    mk = lambda i, **k: dict(dict(id=f"s{i}", post=f"s{i}", shortcode=f"s{i}", permalink="https://www.instagram.com/p/AbC123/", video=False, title="Sample", alt="Sample",
                                  caption="Sample caption", category="Kitchens" if i % 2 else "Cabinet doors", ts="2026-01-01T00:00:00Z", date="Jan 1, 2026", base=f"s{i}",
                                  sizes=[480, 960, 1600], w=1080, h=1350, bg="#e8edf3"), **k)
    return [mk(0), mk(1), mk(2, video=True), mk(3, title="", caption="")]
