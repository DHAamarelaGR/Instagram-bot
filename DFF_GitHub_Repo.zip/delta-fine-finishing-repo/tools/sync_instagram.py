#!/usr/bin/env python3
"""Instagram -> website gallery.

Run by .github/workflows/instagram-sync.yml (or by hand). It
  1. reads your newest Instagram posts,
  2. saves every photo as small WebP files on your own website (site/gallery/),
  3. remembers the posts in data/gallery.json,
  4. rebuilds site/gallery.html and the gallery part of site/sitemap.xml.

Where the posts come from (set ONE of these in GitHub, see LEIA-ME):
  BEHOLD_FEED_URL   repository variable   JSON feed from behold.so (easiest, Behold keeps the Instagram login alive)
  INSTAGRAM_TOKEN   repository secret     long-lived token from the Instagram API (free, no third party)

Nothing on disk changes if something fails before the end. If nothing is new, nothing is written (so no new deploy is triggered).
Needs Python 3.9+ and Pillow (pip install pillow).
"""
import argparse
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gallery_render as gr  # noqa: E402
from PIL import Image, ImageOps  # noqa: E402

Image.MAX_IMAGE_PIXELS = 60_000_000
MAX_IMAGE_BYTES = 30 * 1024 * 1024
MAX_JSON_BYTES = 20 * 1024 * 1024
IG_BASE = os.environ.get("IG_GRAPH_BASE", "https://graph.instagram.com").rstrip("/")
UA = "DeltaFineFinishing-gallery-sync/1.0"


class SyncError(Exception):
    pass


class ApiError(SyncError):
    pass


# ------------------------------------------------------------------ safe downloads
def _extra_hosts():
    return {h.strip().lower() for h in os.environ.get("SYNC_ALLOW_HOSTS", "").split(",") if h.strip()}   # only used by the tests


def _host_ok(host, kind):
    host = (host or "").lower()
    if host in _extra_hosts():
        return True
    if kind == "image":
        return host.endswith((".cdninstagram.com", ".fbcdn.net", ".behold.pictures")) or host in ("cdninstagram.com", "fbcdn.net", "behold.pictures")
    return host in ("graph.instagram.com", "feeds.behold.so")


def _check_url(url, kind):
    u = urllib.parse.urlparse(url)
    local = (u.hostname or "").lower() in _extra_hosts()
    if u.scheme != "https" and not (local and u.scheme == "http"):
        raise SyncError("refusing a non-HTTPS address")
    if not _host_ok(u.hostname, kind):
        raise SyncError(f"refusing to download from an unexpected host: {u.hostname}")


class _Guard(urllib.request.HTTPRedirectHandler):
    def __init__(self, kind):
        self.kind = kind

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _check_url(newurl, self.kind)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def http_get(url, kind, max_bytes, retries=3, timeout=40):
    _check_url(url, kind)
    opener = urllib.request.build_opener(_Guard(kind))
    wait = float(os.environ.get("SYNC_RETRY_WAIT", "2"))
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
            with opener.open(req, timeout=timeout) as r:
                data = r.read(max_bytes + 1)
                if len(data) > max_bytes:
                    raise SyncError("a download was larger than expected")
                return data
        except urllib.error.HTTPError as e:
            body = e.read(4000)
            if e.code in (429, 500, 502, 503, 504) and attempt < retries - 1:
                time.sleep(wait * (attempt + 1))
                continue
            raise ApiError(f"HTTP {e.code}: {body.decode('utf-8', 'replace')[:400]}")
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            last = getattr(e, "reason", e)
            if attempt < retries - 1:
                time.sleep(wait * (attempt + 1))
                continue
    raise SyncError(f"network problem: {last}")


def json_get(url, kind="api"):
    try:
        return json.loads(http_get(url, kind, MAX_JSON_BYTES).decode("utf-8"))
    except ValueError:
        raise SyncError("the answer was not valid JSON")


def explain_api_error(msg):
    m = re.search(r'"code"\s*:\s*(\d+)', msg)
    if m and m.group(1) in ("190", "102"):
        return ("The Instagram token expired or is not valid any more. Create a new token and replace the INSTAGRAM_TOKEN secret in GitHub "
                "(see LEIA-ME, section 'Renew the Instagram token').")
    return msg


# ------------------------------------------------------------------ sources
def shortcode_of(permalink):
    m = re.search(r"instagram\.com/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", permalink or "")
    return m.group(1) if m else None


def fetch_behold(feed_url, limit):
    if not (re.match(r"^https://feeds\.behold\.so/[A-Za-z0-9_-]+/?$", feed_url) or urllib.parse.urlparse(feed_url).hostname in _extra_hosts()):
        raise SyncError("BEHOLD_FEED_URL must look like https://feeds.behold.so/XXXXXXXX")
    data = json_get(feed_url)
    raw = data.get("posts") if isinstance(data, dict) else data
    if not isinstance(raw, list):
        raise SyncError("the Behold feed has no 'posts' list")
    posts = []

    def best(o):
        sizes = o.get("sizes") or {}
        for k in ("full", "large", "medium", "small"):
            u = (sizes.get(k) or {}).get("mediaUrl")
            if u:
                return u
        return o.get("thumbnailUrl") if o.get("mediaType") == "VIDEO" else o.get("mediaUrl")

    for p in raw[:limit]:
        t = p.get("mediaType")
        if t == "CAROUSEL_ALBUM":
            media = [{"url": best(c), "alt": c.get("altText")} for c in (p.get("children") or []) if best(c)]
        else:
            media = [{"url": best(p), "alt": p.get("altText")}] if best(p) else []
        if not p.get("id") or not media:
            continue
        posts.append(dict(id=str(p["id"]), permalink=p.get("permalink"), ts=p.get("timestamp"), caption=p.get("caption") or "",
                          video=(t == "VIDEO"), kind=t, media=media))
    return posts, False       # Behold only shows the newest posts, so we never delete anything because it is missing


def fetch_api(token, limit):
    fields = "id,caption,media_type,media_url,thumbnail_url,permalink,timestamp"
    url = f"{IG_BASE}/me/media?" + urllib.parse.urlencode({"fields": fields, "limit": 50, "access_token": token})
    posts, complete = [], True
    while url:
        data = json_get(url)
        for m in data.get("data", []):
            if len(posts) >= limit:
                complete = False
                break
            t = m.get("media_type")
            if t == "CAROUSEL_ALBUM":
                try:
                    kids = json_get(f"{IG_BASE}/{m['id']}/children?" + urllib.parse.urlencode({"fields": "id,media_type,media_url,thumbnail_url", "access_token": token})).get("data", [])
                except ApiError as e:
                    print(f"::warning::Could not read the photos of album {m.get('id')}: {str(e)[:120]}")
                    continue
                media = [{"url": k.get("thumbnail_url") if k.get("media_type") == "VIDEO" else k.get("media_url")} for k in kids]
            elif t == "VIDEO":
                media = [{"url": m.get("thumbnail_url")}]
            else:
                media = [{"url": m.get("media_url")}]
            media = [x for x in media if x.get("url")]
            if media:
                posts.append(dict(id=str(m["id"]), permalink=m.get("permalink"), ts=m.get("timestamp"), caption=m.get("caption") or "",
                                  video=(t == "VIDEO"), kind=t, media=media))
        if len(posts) >= limit:
            complete = False
            break
        url = (data.get("paging") or {}).get("next")
    return posts, complete


def refresh_token(token):
    j = json_get(f"{IG_BASE}/refresh_access_token?" + urllib.parse.urlencode({"grant_type": "ig_refresh_token", "access_token": token}))
    if not j.get("access_token"):
        raise SyncError("Instagram did not return a new token")
    return j["access_token"], j.get("expires_in")


# ------------------------------------------------------------------ images
def make_files(data, base, outdir):
    im = Image.open(io.BytesIO(data))
    im.load()
    im = ImageOps.exif_transpose(im)
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        rgba = im.convert("RGBA")
        flat = Image.new("RGB", rgba.size, (255, 255, 255))
        flat.paste(rgba, mask=rgba.split()[-1])
        im = flat
    else:
        im = im.convert("RGB")
    W, H = im.size
    if W < 100 or H < 100:
        raise SyncError("image is too small")
    widths = sorted({t for t in gr.WIDTHS if t < W} | {min(W, gr.WIDTHS[-1])})
    r, g, b = im.resize((1, 1), Image.BOX).getpixel((0, 0))
    os.makedirs(outdir, exist_ok=True)
    for w in widths:
        v = im if w == W else im.resize((w, max(1, round(H * w / W))), Image.LANCZOS)     # no EXIF/GPS is written: metadata is not copied
        tmp = os.path.join(outdir, f".{base}-{w}.tmp")
        v.save(tmp, "WEBP", quality=78 if w <= 480 else 80 if w <= 960 else 82, method=6)
        os.replace(tmp, os.path.join(outdir, f"{base}-{w}.webp"))
    top = widths[-1]
    return dict(base=base, sizes=widths, w=top, h=max(1, round(H * top / W)), bg="#%02x%02x%02x" % (r, g, b))


def files_exist(f, outdir):
    return all(os.path.exists(os.path.join(outdir, f"{f['base']}-{w}.webp")) for w in f["sizes"])


def remove_files(f, outdir):
    for w in f.get("sizes", []):
        try:
            os.remove(os.path.join(outdir, f"{f['base']}-{w}.webp"))
        except OSError:
            pass


# ------------------------------------------------------------------ disk
def write_if_changed(path, text, dry=False):
    try:
        with open(path, encoding="utf-8") as f:
            if f.read() == text:
                return False
    except OSError:
        pass
    if not dry:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    return True


def dump_archive(posts):
    posts = sorted(posts, key=lambda p: (p.get("ts") or "", p["id"]), reverse=True)
    return json.dumps({"version": 1, "posts": posts}, indent=1, ensure_ascii=False) + "\n"


def render(root, posts, cfg, overrides, dry=False):
    items = gr.derive_items(posts, cfg, overrides)
    changed = []
    gpath = os.path.join(root, "site", "gallery.html")
    with open(gpath, encoding="utf-8") as f:
        html = f.read()
    if gr.MAIN_A not in html or gr.HEAD_A not in html:
        raise SyncError("site/gallery.html does not have the gallery markers. Upload the site files from the latest ZIP again.")
    if write_if_changed(gpath, gr.apply_gallery(html, items), dry):
        changed.append("site/gallery.html")
    spath = os.path.join(root, "site", "sitemap.xml")
    try:
        with open(spath, encoding="utf-8") as f:
            xml = f.read()
        if gr.SM_A in xml:
            if write_if_changed(spath, gr.apply_sitemap(xml, items), dry):
                changed.append("site/sitemap.xml")
        else:
            print("::warning::site/sitemap.xml has no gallery marker; the sitemap was not updated")
    except OSError:
        print("::warning::site/sitemap.xml not found")
    return items, changed


# ------------------------------------------------------------------ main
def sync(root, dry=False, allow_empty=False):
    site_dir = os.path.join(root, "site")
    data_dir = os.path.join(root, "data")
    out = os.path.join(site_dir, "gallery")
    cfg, ov, archive = gr.load_config(data_dir), gr.load_overrides(data_dir), gr.load_archive(data_dir)
    posts = {str(p["id"]): p for p in archive["posts"]}
    limit = int(os.environ.get("MAX_POSTS") or cfg["max_stored_posts"])

    feed, token = os.environ.get("BEHOLD_FEED_URL", "").strip(), os.environ.get("INSTAGRAM_TOKEN", "").strip()
    fetched, complete, source = [], False, None
    if feed:
        source = "Behold"
        fetched, complete = fetch_behold(feed, limit)
    elif token:
        source = "Instagram API"
        try:
            fetched, complete = fetch_api(token, limit)
        except ApiError as e:
            raise SyncError(explain_api_error(str(e)))
    else:
        print("::warning::Instagram is not connected yet. Add BEHOLD_FEED_URL (variable) or INSTAGRAM_TOKEN (secret) in GitHub. Only the page was refreshed.")

    added = removed = failed = todo = done = 0
    if source:
        print(f"{source}: {len(fetched)} posts read")
        if complete and not fetched and posts and not allow_empty:
            raise SyncError("Instagram returned no posts at all but the gallery has some. Nothing was deleted. Check the connection (or run with --allow-empty).")
        seen = set()
        for fp in fetched:
            seen.add(fp["id"])
            if gr.is_hidden(dict(id=fp["id"], shortcode=shortcode_of(fp["permalink"]), permalink=fp["permalink"]), ov):
                if fp["id"] in posts:
                    for f in posts.pop(fp["id"])["files"]:
                        remove_files(f, out)
                continue
            old = posts.get(fp["id"])
            perm = gr.safe_permalink(fp["permalink"])
            if old and all(files_exist(f, out) for f in old["files"]) and len(old["files"]) == len(fp["media"]):
                old.update(caption=(fp["caption"] or "")[:2200], permalink=perm or old.get("permalink"), shortcode=shortcode_of(perm) or old.get("shortcode"))
                continue
            todo += 1
            slug = gr.slugify(" ".join(gr.clean_lines(fp["caption"]))) or "project"
            key = gr.short_id(fp["id"])
            files = []
            try:
                for i, m in enumerate(fp["media"]):
                    data = http_get(m["url"], "image", MAX_IMAGE_BYTES)
                    base = f"{slug}-{key}" + (f"-{i + 1}" if i else "")
                    f = make_files(data, base, out)
                    if m.get("alt"):
                        f["alt"] = str(m["alt"])[:300]
                    files.append(f)
            except (SyncError, OSError, ValueError, Image.UnidentifiedImageError) as e:
                failed += 1
                for f in files:
                    remove_files(f, out)
                print(f"::warning::Could not save post {fp['id']}: {e}")
                continue
            done += 1
            if old:
                for f in old["files"]:
                    remove_files(f, out)
            else:
                added += 1
            posts[fp["id"]] = dict(id=fp["id"], shortcode=shortcode_of(perm), permalink=perm, type="VIDEO" if fp["video"] else ("CAROUSEL" if len(files) > 1 else "IMAGE"),
                                   video=fp["video"], ts=gr.iso(fp["ts"]) or "1970-01-01T00:00:00Z", caption=(fp["caption"] or "")[:2200], files=files)
        if complete:       # the whole feed was read, so a post that is gone from Instagram is removed here too
            for pid in [k for k in posts if k not in seen]:
                for f in posts.pop(pid)["files"]:
                    remove_files(f, out)
                removed += 1
        if todo >= 3 and not done:       # one broken photo only warns; every photo failing means something is wrong (network, blocked address...)
            raise SyncError("none of the new photos could be saved")
    # hidden posts and the size cap
    for pid in [k for k, p in posts.items() if gr.is_hidden(p, ov)]:
        for f in posts.pop(pid)["files"]:
            remove_files(f, out)
    ordered = sorted(posts.values(), key=lambda p: (p.get("ts") or "", p["id"]), reverse=True)
    for p in ordered[limit:]:
        for f in p["files"]:
            remove_files(f, out)
        posts.pop(p["id"], None)
    allposts = list(posts.values())

    os.makedirs(data_dir, exist_ok=True)
    changed = []
    if write_if_changed(os.path.join(data_dir, "gallery.json"), dump_archive(allposts), dry):
        changed.append("data/gallery.json")
    items, ch = render(root, allposts, cfg, ov, dry)
    changed += ch
    # photo files nobody refers to (for example from an earlier failed run)
    keep = {f"{f['base']}-{w}.webp" for p in allposts for f in p["files"] for w in f["sizes"]}
    if os.path.isdir(out) and not dry:
        for name in os.listdir(out):
            if name.endswith((".webp", ".tmp")) and name not in keep:
                try:
                    os.remove(os.path.join(out, name))
                    changed.append(f"site/gallery/{name} (removed)")
                except OSError:
                    pass
    print(f"Posts on file: {len(allposts)} | photos on the page: {len(items)} | new: {added} | removed: {removed} | could not save: {failed}")
    print("Changed: " + (", ".join(changed[:12]) + (" ..." if len(changed) > 12 else "") if changed else "nothing"))
    return changed


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=os.path.dirname(HERE), help="folder that holds site/ and data/ (default: the folder above tools/)")
    ap.add_argument("--render-only", action="store_true", help="only rebuild gallery.html and the sitemap from data/gallery.json")
    ap.add_argument("--refresh-token", action="store_true", help="print a renewed 60-day INSTAGRAM_TOKEN and exit")
    ap.add_argument("--allow-empty", action="store_true", help="accept an empty answer from Instagram even though the gallery has photos")
    ap.add_argument("--dry-run", action="store_true", help="do not write anything")
    a = ap.parse_args(argv)
    secrets = [os.environ.get("INSTAGRAM_TOKEN", "").strip()]
    redact = lambda s: re.sub(r"access_token=[^&\s\"']+", "access_token=***", s if not secrets[0] else s.replace(secrets[0], "***"))
    try:
        if a.refresh_token:
            tok = secrets[0]
            if not tok:
                raise SyncError("INSTAGRAM_TOKEN is not set")
            new, left = refresh_token(tok)
            print(new)
            if left:
                print(f"renewed for {int(left) // 86400} days", file=sys.stderr)
            return 0
        if a.render_only:
            cfg, ov, arch = gr.load_config(os.path.join(a.root, "data")), gr.load_overrides(os.path.join(a.root, "data")), gr.load_archive(os.path.join(a.root, "data"))
            items, ch = render(a.root, arch["posts"], cfg, ov, a.dry_run)
            print(f"Photos on the page: {len(items)} | changed: {', '.join(ch) or 'nothing'}")
            return 0
        sync(a.root, a.dry_run, a.allow_empty)
        return 0
    except SyncError as e:
        print("ERROR: " + redact(str(e)), file=sys.stderr)
        return 1
    except Exception as e:      # never print a traceback that could contain an address with the token
        print(f"ERROR: unexpected problem ({type(e).__name__}): {redact(str(e))}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
