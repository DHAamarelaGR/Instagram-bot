# Instagram → Galeria do site (passo a passo)

Tudo o que você postar no Instagram **@dfinefinishing** aparece sozinho na página **Gallery** do site, com as fotos já otimizadas e hospedadas no seu próprio domínio. Nenhum script do Instagram é carregado na página, então o site continua rápido e o Google consegue ler as fotos.

## Como funciona

1. Um "robô" gratuito do GitHub roda **toda segunda e quinta** (e quando você clicar em um botão).
2. Ele lê os posts novos, reduz cada foto para 3 tamanhos em WebP, tira dados escondidos (como localização GPS) e guarda tudo na pasta `site/gallery`.
3. Ele refaz a página `gallery.html`, o mapa do site (`sitemap.xml`) e os dados para o Google (JSON-LD).
4. Quando há post novo, o Netlify publica o site sozinho. Se não há post novo, nada é publicado.

## Antes de começar: 3 avisos importantes

1. **A conta do Instagram precisa ser Profissional** (Comercial ou Criador de conteúdo) e pública. É grátis e dá para desfazer. No app: *Configurações → Tipo de conta e ferramentas → Mudar para conta profissional* (os nomes dos menus mudam de vez em quando).
2. **Créditos do Netlify.** Segundo a documentação do Netlify, nos planos novos cada publicação de produção custa **15 créditos** e o plano Free tem **300 créditos por mês** (cerca de 20 publicações). Se os créditos acabam, o site fica fora do ar até o mês seguinte. Por isso o robô roda só 2 vezes por semana (no máximo uns 9 a 10 publicações por mês). Veja o seu plano em *Netlify → Team → Billing*. Se o seu plano for antigo e não usar créditos, você pode rodar todo dia (veja "Mudar a frequência").
3. **Escolha como conectar o Instagram:**

| | **Opção A: Behold (mais fácil)** | **Opção B: Instagram direto (mais completa)** |
|---|---|---|
| Custo | Grátis (mostra os 6 posts mais recentes, 1 atualização por dia) | Grátis |
| Posts antigos | Só os 6 últimos, depois o robô vai juntando os novos | Importa até 400 posts de uma vez |
| Post apagado no Instagram | Continua no site até você esconder (veja abaixo) | Some do site sozinho |
| Passos | ~5 minutos | ~20 minutos (conta de desenvolvedor da Meta) |
| Renovação | O Behold cuida do login | Token de 60 dias: renova sozinho se você fizer o passo 6 |

Dica: se você quer importar seus posts antigos pela Opção A, assine o plano Starter do Behold por 1 mês (50 posts, US$ 10/mês segundo a página de preços deles), deixe o robô rodar e depois volte para o Free. Confira as regras atuais em behold.so/pricing.

---

## Parte 1: GitHub (uma vez só, ~15 minutos)

1. Crie uma conta grátis em **github.com**.
2. Clique em **New repository**. Nome: `dff-website`. Marque **Private**. Não marque "Add a README". Clique em **Create repository**.
3. Descompacte o arquivo **DFF_GitHub_Repo.zip**. Dentro dele há a pasta `delta-fine-finishing-repo`.
4. Na página do repositório vazio, clique em **uploading an existing file**. Arraste para a janela **o conteúdo** da pasta (as pastas `site`, `tools`, `data` e os arquivos `netlify.toml`, `LEIA-ME_INSTAGRAM.md`, etc.). O GitHub aceita até 100 arquivos por vez. Se ele recusar, envie primeiro tudo menos `site/images` e depois `site/images` em um segundo envio. Clique em **Commit changes**.
5. A pasta escondida `.github` pode não ser enviada pelo arraste. Crie o arquivo do robô direto no GitHub: **Add file → Create new file**. No campo do nome digite exatamente `.github/workflows/instagram-sync.yml` (as barras criam as pastas). Cole o conteúdo do arquivo `instagram-sync.yml` que está na raiz do ZIP (ou o bloco no fim deste guia). Clique em **Commit changes**.
6. Vá em **Settings → Actions → General → Workflow permissions**, marque **Read and write permissions** e clique em **Save**.

## Parte 2: Netlify (~5 minutos)

O site já está no Netlify. Agora ele passa a ser publicado a partir do GitHub.

1. No Netlify abra o seu site e vá em **Site configuration → Build & deploy → Continuous deployment**. Clique em **Link repository** (o nome do botão pode variar um pouco), escolha **GitHub**, autorize o Netlify e escolha `dff-website`.
2. Branch: `main`. **Build command: deixe vazio.** **Publish directory: `site`** (o arquivo `netlify.toml` já diz isso). Salve.
3. O Netlify publica. Abra o site e confira se tudo está igual (formulários, páginas, logo). A partir daqui você **não arrasta mais a pasta** no Netlify: tudo vem do GitHub.

Se você não achar a opção "Link repository", me avise que eu te guio para criar o site a partir do GitHub e mudar o domínio.

## Parte 3: Conectar o Instagram

### Opção A: Behold

1. Crie uma conta em **behold.so** e crie um feed conectando o seu Instagram (precisa ser conta profissional, como no aviso 1).
2. Abra o feed e copie o endereço do **JSON feed**. Ele parece com `https://feeds.behold.so/XXXXXXXX`.
3. No GitHub: **Settings → Secrets and variables → Actions → aba Variables → New repository variable**. Nome: `BEHOLD_FEED_URL`. Valor: o endereço copiado. Clique em **Add variable**.

### Opção B: Instagram direto (sem terceiros)

Os menus da Meta mudam bastante. O caminho abaixo vem da documentação oficial deles (developers.facebook.com/documentation/instagram-platform). Se a tela estiver diferente, me mande uma captura e eu ajusto o passo.

1. Entre em **developers.facebook.com** com a sua conta do Facebook e crie a conta de desenvolvedor.
2. **My Apps → Create App.** Escolha um app do tipo **Business** (nome: `DFF Gallery`).
3. No painel do app, adicione o produto **Instagram** e abra **API setup with Instagram business login**.
4. Em "Generate access tokens", adicione a sua conta profissional do Instagram (faça login e aceite). Depois clique em **Generate token** ao lado dela e **copie o token**. Ele vale 60 dias. Se pedir para a conta ser "Instagram Tester", aceite o convite no app do Instagram.
5. No GitHub: **Settings → Secrets and variables → Actions → aba Secrets → New repository secret**. Nome: `INSTAGRAM_TOKEN`. Valor: o token. **Nunca cole esse token em outro lugar.**
6. **Renovação automática (recomendado).** Sem este passo o token vence em 60 dias e o robô avisa por e-mail do GitHub que falhou. Para renovar sozinho: no GitHub clique na sua foto → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**. Em *Repository access* escolha **Only select repositories → dff-website**. Em *Repository permissions* coloque **Secrets: Read and write**. Escolha a validade mais longa e gere. Copie o token e crie outro secret chamado `GH_PAT`. (Esse token do GitHub vence em até 1 ano e o GitHub avisa por e-mail antes.)

## Parte 4: Primeira vez

1. No GitHub abra a aba **Actions**. Se aparecer um aviso para habilitar workflows, habilite.
2. Clique em **Update gallery from Instagram → Run workflow → Run workflow**.
3. Espere 1 a 3 minutos (mais se você importar muitos posts). Um ✔ verde é sucesso. Clique na execução e no passo "Read new Instagram posts" para ver, por exemplo, `Posts on file: 12`.
4. O Netlify publica em cerca de 1 minuto. Abra **www.deltafinefinishing.com/gallery.html**.
5. Depois de ver as fotos, peça no Google Search Console para reindexar a página `/gallery.html` (ela só entra no Google quando tem foto).

## Dia a dia

- Poste normalmente. As fotos entram na próxima segunda ou quinta. Para entrar já, use **Actions → Run workflow**.
- **A legenda vira SEO.** A primeira frase vira o título e a descrição da foto que o Google lê. Escreva em inglês, diga o que é (ex.: "Navy shaker kitchen with quartz island in Brookfield, CT"). Hashtags, links, @menções e emojis são retirados do texto da página.
- **Filtros.** As palavras da legenda e das hashtags escolhem a categoria: kitchen (Kitchens), vanity (Bathrooms), closet ou built-in (Closets & built-ins), door ou shaker (Cabinet doors), shop ou CNC (Shop & process). Para mudar as regras, edite `data/config.json`.
- **Carrossel.** Cada foto do carrossel aparece na galeria. **Vídeo e Reels** aparecem como capa com botão de play que abre o Instagram. **Stories não entram.**
- **Esconder um post.** Abra `data/overrides.json` no GitHub (lápis para editar) e coloque o código do link do Instagram (`instagram.com/p/CODIGO/`) em `"hide"`, assim: `"hide": ["CODIGO"]`. Na Opção A é também assim que você tira do site um post que apagou no Instagram.
- **Mudar título, texto ou categoria de um post:** em `data/overrides.json`, em `"posts"`: `"CODIGO": {"title": "...", "alt": "...", "category": "Kitchens"}`.
- **Mudar a frequência:** no arquivo `.github/workflows/instagram-sync.yml`, altere a linha `cron`. Exemplo: `"17 14 * * *"` roda todo dia (só faça isso se o seu Netlify não usa créditos ou se você posta pouco).
- **Quando eu te mandar uma versão nova do site:** envie só o conteúdo da pasta `site` para o GitHub (não mexa em `data` nem em `site/gallery`) e depois clique em **Run workflow** para a galeria voltar na hora.

## Se algo der errado

Abra **Actions**, clique na execução com ✖ vermelho e leia as últimas linhas.

| Mensagem | O que fazer |
|---|---|
| `Instagram is not connected yet` | Falta criar a variável `BEHOLD_FEED_URL` ou o secret `INSTAGRAM_TOKEN` (Parte 3). |
| `The Instagram token expired` | Refaça os passos 4 e 5 da Opção B (token novo) e faça o passo 6 para não acontecer de novo. |
| `BEHOLD_FEED_URL must look like https://feeds.behold.so/...` | O endereço da variável está errado. Copie de novo no Behold. |
| `Instagram returned no posts at all` | Nada foi apagado. Confira se a conta continua profissional e pública, e rode de novo. |
| `gallery markers` | O arquivo `site/gallery.html` foi trocado por uma versão antiga. Envie de novo o `site/gallery.html` do ZIP mais recente. |
| Netlify mostra "Site not available" | Os créditos do mês acabaram. Veja *Team → Billing*. |

## Segurança e privacidade

- O token fica só nos *Secrets* do GitHub (cifrado). Ele nunca vai para o site nem para os logs.
- O repositório deve ficar **Private**.
- Cada foto é regravada sem dados escondidos (câmera, GPS).
- A página não carrega nada do Instagram. Só quando o visitante clica em "View on Instagram" ele vai para o Instagram.

---

## Arquivo do robô (para o passo 5 da Parte 1)

Nome do arquivo: `.github/workflows/instagram-sync.yml`

```yaml
# Updates the website gallery from Instagram.
# Runs twice a week by itself and whenever you press "Run workflow" (Actions tab). It only saves something when there are new posts,
# and every save publishes the site on Netlify once. Change the days below if you want it more or less often:
#   "17 14 * * 1,4"  = Monday and Thursday at 14:17 UTC (10:17 in Connecticut in summer)
#   "17 14 * * *"    = every day
name: Update gallery from Instagram

on:
  schedule:
    - cron: "17 14 * * 1,4"
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: instagram-sync
  cancel-in-progress: false

jobs:
  sync:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v6

      - uses: actions/setup-python@v6
        with:
          python-version: "3.12"

      - name: Install Pillow (image resizer)
        run: pip install -r tools/requirements.txt

      - name: Read new Instagram posts and save the photos
        env:
          BEHOLD_FEED_URL: ${{ vars.BEHOLD_FEED_URL }}
          INSTAGRAM_TOKEN: ${{ secrets.INSTAGRAM_TOKEN }}
          GH_PAT: ${{ secrets.GH_PAT }}
          GH_REPO: ${{ github.repository }}
        run: |
          # Optional: with the INSTAGRAM_TOKEN + GH_PAT secrets the 60-day token renews itself every run.
          if [ -z "$BEHOLD_FEED_URL" ] && [ -n "$INSTAGRAM_TOKEN" ] && [ -n "$GH_PAT" ]; then
            if NEW=$(python tools/sync_instagram.py --refresh-token); then
              echo "::add-mask::$NEW"
              printf '%s' "$NEW" | GH_TOKEN="$GH_PAT" gh secret set INSTAGRAM_TOKEN --repo "$GH_REPO"
              export INSTAGRAM_TOKEN="$NEW"
            else
              echo "::warning::Could not renew the Instagram token this time (a token must be at least 1 day old). Using the current one."
            fi
          fi
          python tools/sync_instagram.py

      - name: Save the changes (this publishes the site on Netlify)
        run: |
          git config user.name "Instagram sync"
          git config user.email "actions@users.noreply.github.com"
          git add -A site data
          if git diff --cached --quiet; then
            echo "No new Instagram posts."
          else
            git commit -m "Update gallery from Instagram"
            git pull --rebase origin "$GITHUB_REF_NAME"
            git push origin "HEAD:$GITHUB_REF_NAME"
          fi
```
